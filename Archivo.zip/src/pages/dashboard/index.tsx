import React from "react";
import HeaderFooterWraper from "../../app/components/layout/InitWraper";

const index = () => {
  return (
    <HeaderFooterWraper>
      <div></div>
    </HeaderFooterWraper>
  );
};

export default index;
