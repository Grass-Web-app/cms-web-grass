exports.id = 904;
exports.ids = [904];
exports.modules = {

/***/ 6392:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const URL = `${"https://backend.fustadesign.com/api/v1/"}`;
const useAxiosDelete = (endpoint, options)=>{
    const { 0: isLoading , 1: setisLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const Delete = async (token, id)=>{
        try {
            var ref, ref1;
            const resp = await axios__WEBPACK_IMPORTED_MODULE_1___default()({
                method: "delete",
                url: `${URL}${endpoint}${id}`,
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            if (options === null || options === void 0 ? void 0 : (ref = options.completeInterceptor) === null || ref === void 0 ? void 0 : ref.action) {
                setisLoading(true);
                options.completeInterceptor.action(resp);
            }
            if (options === null || options === void 0 ? void 0 : (ref1 = options.completeInterceptor) === null || ref1 === void 0 ? void 0 : ref1.message) {
                var ref2;
                console.log(options === null || options === void 0 ? void 0 : (ref2 = options.completeInterceptor) === null || ref2 === void 0 ? void 0 : ref2.message);
            }
        } catch (err) {
            var ref3, ref4;
            if (options === null || options === void 0 ? void 0 : (ref3 = options.errorInterceptor) === null || ref3 === void 0 ? void 0 : ref3.action) {
                setisLoading(true);
                options.errorInterceptor.action();
            }
            if (options === null || options === void 0 ? void 0 : (ref4 = options.errorInterceptor) === null || ref4 === void 0 ? void 0 : ref4.message) {
                var ref5;
                console.log(options === null || options === void 0 ? void 0 : (ref5 = options.errorInterceptor) === null || ref5 === void 0 ? void 0 : ref5.message);
            }
        }
    };
    return {
        Delete,
        isLoading
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useAxiosDelete);


/***/ }),

/***/ 3782:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const URL = `${"https://backend.fustadesign.com/api/v1/"}`;
const useAxiosPatch = (endpoint, options)=>{
    const { 0: isLoading , 1: setisLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const Patch = async (dataBody, headers)=>{
        try {
            var ref, ref1;
            const resp = await axios__WEBPACK_IMPORTED_MODULE_1___default()({
                method: "patch",
                url: `${URL}${endpoint}`,
                headers: headers,
                data: dataBody
            });
            if (options === null || options === void 0 ? void 0 : (ref = options.completeInterceptor) === null || ref === void 0 ? void 0 : ref.action) {
                setisLoading(true);
                options.completeInterceptor.action(resp);
            }
            if (options === null || options === void 0 ? void 0 : (ref1 = options.completeInterceptor) === null || ref1 === void 0 ? void 0 : ref1.message) {
                var ref2;
                console.log(options === null || options === void 0 ? void 0 : (ref2 = options.completeInterceptor) === null || ref2 === void 0 ? void 0 : ref2.message);
            }
        } catch (err) {
            var ref3, ref4;
            if (options === null || options === void 0 ? void 0 : (ref3 = options.errorInterceptor) === null || ref3 === void 0 ? void 0 : ref3.action) {
                setisLoading(true);
                options.errorInterceptor.action();
            }
            if (options === null || options === void 0 ? void 0 : (ref4 = options.errorInterceptor) === null || ref4 === void 0 ? void 0 : ref4.message) {
                var ref5;
                console.log(options === null || options === void 0 ? void 0 : (ref5 = options.errorInterceptor) === null || ref5 === void 0 ? void 0 : ref5.message);
            }
        }
    };
    return {
        Patch,
        isLoading
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useAxiosPatch);


/***/ }),

/***/ 1501:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U7": () => (/* binding */ timems),
/* harmony export */   "fZ": () => (/* binding */ SuccessCreateMessageToast),
/* harmony export */   "wk": () => (/* binding */ ErrorCreateMessageToast),
/* harmony export */   "xz": () => (/* binding */ SuccessEdithMessageToast),
/* harmony export */   "Jf": () => (/* binding */ ErrorEdithMessageToast)
/* harmony export */ });
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8922);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_hot_toast__WEBPACK_IMPORTED_MODULE_0__);

const timems = 4000;
const SuccessCreateMessageToast = (title)=>react_hot_toast__WEBPACK_IMPORTED_MODULE_0___default().success(`Registro "${title}" creado exitosamente`, {
        duration: timems,
        style: {
            background: "#d5eddb",
            color: "#376f43"
        }
    })
;
const ErrorCreateMessageToast = (title)=>react_hot_toast__WEBPACK_IMPORTED_MODULE_0___default().error(`No se pudo borrar el registro "${title}", contacta con soporte o verificar los campos`, {
        duration: timems,
        style: {
            background: "#f7d7db",
            color: "#84373f"
        }
    })
;
const SuccessEdithMessageToast = (title)=>react_hot_toast__WEBPACK_IMPORTED_MODULE_0___default().success(`Registro "${title}" editado exitosamente`, {
        duration: timems,
        style: {
            background: "#d5eddb",
            color: "#376f43"
        }
    })
;
const ErrorEdithMessageToast = (title)=>react_hot_toast__WEBPACK_IMPORTED_MODULE_0___default().error(`No se pudo Editar el registro "${title}", contacta con soporte o verificar los campos`, {
        duration: timems,
        style: {
            background: "#f7d7db",
            color: "#84373f"
        }
    })
;


/***/ }),

/***/ 2746:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8922);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_hot_toast__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Reduxhooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5673);
/* harmony import */ var _Hooks_useAxiosDelete__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6392);
/* harmony import */ var _ReduxSlices_CookiesSlice__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3844);
/* harmony import */ var _ToastFunctions_toast_functions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1501);
/* harmony import */ var _styledCatalog__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(95);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ReduxSlices_CookiesSlice__WEBPACK_IMPORTED_MODULE_5__]);
_ReduxSlices_CookiesSlice__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];








const Catalog = (props)=>{
    const { id , title , subtitle , icon , setcatalog , endpointErase , fnErase  } = props;
    const token = (0,_Reduxhooks__WEBPACK_IMPORTED_MODULE_3__/* .useAppSelector */ .CG)(_ReduxSlices_CookiesSlice__WEBPACK_IMPORTED_MODULE_5__/* .Token */ .WU);
    const { 0: showOprions , 1: setShowOprions  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { Delete  } = (0,_Hooks_useAxiosDelete__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(endpointErase, {
        completeInterceptor: {
            action: ()=>{
                Success();
                fnErase();
            }
        },
        errorInterceptor: {
            action: ()=>{
                Error();
            }
        }
    });
    const handleEraseData = ()=>{
        Delete(token.access, id);
    };
    const Success = ()=>react_hot_toast__WEBPACK_IMPORTED_MODULE_2___default().success(`Registro "${title}" con id #${id} borrado exitosamente`, {
            duration: _ToastFunctions_toast_functions__WEBPACK_IMPORTED_MODULE_6__/* .timems */ .U7,
            style: {
                background: "#d5eddb",
                color: "#376f43"
            }
        })
    ;
    const Error = ()=>react_hot_toast__WEBPACK_IMPORTED_MODULE_2___default().error(`No se pudo borrar el registro "${title}" con id #${id}, contacta con soporte`, {
            duration: _ToastFunctions_toast_functions__WEBPACK_IMPORTED_MODULE_6__/* .timems */ .U7,
            style: {
                background: "#f7d7db",
                color: "#84373f"
            }
        })
    ;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledCatalog__WEBPACK_IMPORTED_MODULE_7__/* .DivTextContainer */ .Lq, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styledCatalog__WEBPACK_IMPORTED_MODULE_7__/* .PtitleUpper */ .Mt, {
                    children: [
                        "#",
                        id
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledCatalog__WEBPACK_IMPORTED_MODULE_7__/* .DivTextContainer */ .Lq, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledCatalog__WEBPACK_IMPORTED_MODULE_7__/* .PtitleUpper */ .Mt, {
                    children: title
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledCatalog__WEBPACK_IMPORTED_MODULE_7__/* .DivImgImglist */ ._i, {
                show: (icon !== null).toString(),
                children: icon !== null && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledCatalog__WEBPACK_IMPORTED_MODULE_7__/* .ImgShowInList */ .e0, {
                    alt: "image",
                    src: icon
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledCatalog__WEBPACK_IMPORTED_MODULE_7__/* .DivTextContainer */ .Lq, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledCatalog__WEBPACK_IMPORTED_MODULE_7__/* .PtitleUpper */ .Mt, {
                    children: subtitle
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledCatalog__WEBPACK_IMPORTED_MODULE_7__/* .DivTextContainer */ .Lq, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styledCatalog__WEBPACK_IMPORTED_MODULE_7__/* .DivIconOptionsContainer */ .t6, {
                    onClick: ()=>setShowOprions(!showOprions)
                    ,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledCatalog__WEBPACK_IMPORTED_MODULE_7__/* .ImgShowOptions */ .KL, {
                            alt: "image",
                            src: __webpack_require__(7756)
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styledCatalog__WEBPACK_IMPORTED_MODULE_7__/* .DivOptions */ .tE, {
                            show: showOprions.toString(),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styledCatalog__WEBPACK_IMPORTED_MODULE_7__/* .POption */ .Om, {
                                    onClick: setcatalog,
                                    children: [
                                        "Editar",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledCatalog__WEBPACK_IMPORTED_MODULE_7__/* .SpanOption */ .AG, {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledCatalog__WEBPACK_IMPORTED_MODULE_7__/* .ImgShowOptions */ .KL, {
                                                alt: "image",
                                                src: __webpack_require__(8663)
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styledCatalog__WEBPACK_IMPORTED_MODULE_7__/* .POption */ .Om, {
                                    onClick: handleEraseData,
                                    children: [
                                        "Eliminar",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledCatalog__WEBPACK_IMPORTED_MODULE_7__/* .SpanOption */ .AG, {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledCatalog__WEBPACK_IMPORTED_MODULE_7__/* .ImgShowOptions */ .KL, {
                                                alt: "image",
                                                src: __webpack_require__(3006)
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Catalog);

});

/***/ }),

/***/ 95:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FT": () => (/* binding */ DivContainerCatalog),
/* harmony export */   "w8": () => (/* binding */ DivAddNew),
/* harmony export */   "nx": () => (/* binding */ PWhere),
/* harmony export */   "as": () => (/* binding */ ButtonAddList),
/* harmony export */   "lp": () => (/* binding */ TextAdd),
/* harmony export */   "bb": () => (/* binding */ DivIcon),
/* harmony export */   "EV": () => (/* binding */ ImgIcon),
/* harmony export */   "CY": () => (/* binding */ DivListOptions),
/* harmony export */   "Cz": () => (/* binding */ DivUpperList),
/* harmony export */   "Mt": () => (/* binding */ PtitleUpper),
/* harmony export */   "_i": () => (/* binding */ DivImgImglist),
/* harmony export */   "e0": () => (/* binding */ ImgShowInList),
/* harmony export */   "t6": () => (/* binding */ DivIconOptionsContainer),
/* harmony export */   "KL": () => (/* binding */ ImgShowOptions),
/* harmony export */   "Lq": () => (/* binding */ DivTextContainer),
/* harmony export */   "tE": () => (/* binding */ DivOptions),
/* harmony export */   "Om": () => (/* binding */ POption),
/* harmony export */   "AG": () => (/* binding */ SpanOption)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const upperTops = `
  border-top-right-radius: 15px;
  border-top-left-radius: 15px;
  `;
const upperBottom = `
  border-bottom-right-radius: 15px;
  border-bottom-left-radius: 15px;
  `;
const DivContainerCatalog = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  background: #f3f4f6;
`;
const DivAddNew = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  padding: 2%;
  display: flex;
  flex-direction: row-reverse;
  justify-content: space-between;
`;
const PWhere = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().p)`
  font-size: 1rem;
  margin: 0;
  display: flex;
  align-items: center;
  @media (min-width: 1020px) {
    font-size: 1.5rem;
  }
`;
const ButtonAddList = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().button)`
  background: white;
  border-radius: 15px;
  display: flex;
  align-items: center;
  width: fit-content;
  cursor: pointer;
  box-shadow: 2px 5px 5px grey;
  border: none;
  border-style: solid;
  border-width: 1px;
  border-color: #d7dce6;
  @media (min-width: 1020px) {
    padding: 10px;
  }
`;
const TextAdd = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().p)`
  padding-right: 5%;
  white-space: nowrap;
`;
const DivIcon = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 5vh;
`;
const ImgIcon = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().img)`
  width: 100%;
  height: auto;
`;
const DivListOptions = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  height: 100%;
  margin-left: 4%;
  margin-right: 4%;
  height: fit-content;
  border-radius: 15px;
`;
const DivUpperList = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  width: 90vw;
  display: grid;
  grid-template-columns: ${(props)=>props.icon === "false" ? "20%20%40%20%" : "20%20%20%20%20%"
};
  background: #d7dce6;
  border-bottom-style: solid;
  border-width: 1px;
  border-color: grey;
  height: ${(props)=>props.up ? "50" : "100"
}px;
  ${(props)=>props.up && upperTops
}
  ${(props)=>props.bot === "true" && upperBottom
}
  @media (min-width: 1020px) {
    width: auto;
  }
`;
const PtitleUpper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().p)`
  text-align: center;
  width: 100%;
  font-weight: bold;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
`;
const DivImgImglist = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  display: ${(props)=>props.show === "false" ? "none" : "flex"
};
  align-items: center;
  justify-content: center;
  height: 80%;
  align-self: center;
  overflow: hidden;
`;
const ImgShowInList = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().img)`
  width: 50%;
  height: 100%;
  object-fit: cover;
`;
const DivIconOptionsContainer = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  width: auto;
  height: 25%;
  padding: 1%;
  border-radius: 15px;
  position: relative;
  &:hover {
    background: #f0f0f0;
  }
`;
const ImgShowOptions = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().img)`
  width: auto;
  height: 100%;
  cursor: pointer;
`;
const DivTextContainer = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100px;
`;
const DivOptions = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  background: white;
  position: absolute;
  border-radius: 16px;
  right: 0;
  top: 100%;
  margin: auto;
  overflow: hidden;
  width: 200px;
  height: 50px;
  border-color: #f1f1f1;
  border-style: solid;
  border-width: 1px;
  z-index: 10;
  display: ${(props)=>props.show === "false" ? "none" : "flex"
};
  flex-direction: column;
  justify-content: space-around;
  @media (min-width: 1020px) {
    left: -100px;
    right: auto;
  }
`;
const POption = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().p)`
  cursor: pointer;
  margin: 0;
  padding: 0;
  padding-left: 10px;
  display: flex;
  align-items: center;
  &:hover {
    background: #286579;
    color: white;
  }
`;
const SpanOption = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().span)`
  padding-left: 5px;
  height: 15px;
`;


/***/ }),

/***/ 7313:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BG": () => (/* binding */ DivContainerFormCatalog),
/* harmony export */   "IB": () => (/* binding */ DivFormulary),
/* harmony export */   "C2": () => (/* binding */ ButtonBackArrow),
/* harmony export */   "R3": () => (/* binding */ ImgIconArrow),
/* harmony export */   "HR": () => (/* binding */ HR),
/* harmony export */   "UQ": () => (/* binding */ DivButtons),
/* harmony export */   "Tl": () => (/* binding */ ButtonAceptarCancel),
/* harmony export */   "rw": () => (/* binding */ DivInputContainer),
/* harmony export */   "nE": () => (/* binding */ PObligatory),
/* harmony export */   "T2": () => (/* binding */ PText),
/* harmony export */   "TQ": () => (/* binding */ InputNormal),
/* harmony export */   "d2": () => (/* binding */ InputDescription),
/* harmony export */   "sF": () => (/* binding */ InputImg),
/* harmony export */   "WV": () => (/* binding */ DivImgFormulary),
/* harmony export */   "Qc": () => (/* binding */ DivImgCloud),
/* harmony export */   "NE": () => (/* binding */ ImgCloud),
/* harmony export */   "$b": () => (/* binding */ HavePicture),
/* harmony export */   "I6": () => (/* binding */ ImgFile),
/* harmony export */   "bE": () => (/* binding */ DivCatalogOptions),
/* harmony export */   "eE": () => (/* binding */ PoptionCatalogue),
/* harmony export */   "Y5": () => (/* binding */ DivBenefitOpcion),
/* harmony export */   "YP": () => (/* binding */ Pbenefit),
/* harmony export */   "iR": () => (/* binding */ DivImgBenefitOption),
/* harmony export */   "k3": () => (/* binding */ ImgBenefit),
/* harmony export */   "Cz": () => (/* binding */ DivCheck),
/* harmony export */   "Vi": () => (/* binding */ InputCheck)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const borderRed = `
  border-style: solid;
  border-width: 1px;
  border-color: red;
`;
const DivContainerFormCatalog = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  padding: 2%;
  background: #f3f4f6;
  overflow: scroll;
`;
const DivFormulary = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  border-radius: 15px;
  background: #d7dce6;
  padding: 1%;
`;
const ButtonBackArrow = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().button)`
  border: none;
  display: flex;
  align-items: center;
  width: fit-content;
  height: 35px;
  font-size: 1.5rem;
  cursor: pointer;
  background: transparent;
  border-radius: 15px;
  &:hover {
    background: #ddfaeb;
  }
  @media (min-width: 1020px) {
    font-size: 2rem;
  }
`;
const ImgIconArrow = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().img)`
  height: 80%;
  width: auto;
`;
const HR = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().hr)`
  color: grey;
`;
const DivButtons = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  width: 100%;
  display: flex;
  justify-content: space-between;
  margin-top: 40px;
`;
const ButtonAceptarCancel = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().button)`
  width: 48%;
  height: 35px;
  border-radius: 10px;
  border: none;
  cursor: pointer;
  opacity: ${(props)=>props.disabled === "true" && "0.5"
};
  background: ${(props)=>props.disabled === "true" && "#d6d8d9"
};
  &:hover {
    background: #286579;
    color: white;
  }
`;
const DivInputContainer = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  margin-top: 10px;
  position: relative;
`;
const PObligatory = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().p)`
  padding: 0;
  margin: 0;
  margin-top: 5px;
  font-size: 12px;
  position: absolute;
  color: red;
  width: 100%;
  text-align: right;
  display: ${(props)=>props.show === "false" && "none"
};
  z-index: 5;
`;
const PText = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().p)``;
const InputNormal = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().input)`
  height: 100%;
  width: 100%;
  height: 35px;
  background: #ddebe1;
  border-radius: 10px;
  outline: none;
  border: none;
  padding-left: 15px;
  ${(props)=>props.show === "true" && borderRed
}
`;
const InputDescription = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().textarea)`
  height: 100%;
  width: 100%;
  height: 70px;
  background: #ddebe1;
  border-radius: 10px;
  outline: none;
  border: none;
  padding-left: 15px;
  ${(props)=>props.show === "true" && borderRed
}
`;
const InputImg = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().input)`
  opacity: 0;
  width: 100%;
  height: 100%;
  border: none;
  outline: none;
  cursor: pointer;
  position: absolute;
  z-index: 10;
`;
const DivImgFormulary = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  overflow: hidden;
  background: #ddebe1;
  margin-top: 10px;
  height: 150px;
  border-radius: 15px;
  position: relative;
  ${(props)=>props.show === "true" && borderRed
}
`;
const DivImgCloud = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  margin: auto;
  position: absolute;
  z-index: 5;
  display: flex;
  align-items: center;
  justify-content: center;
`;
const ImgCloud = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().img)`
  height: 85%;
`;
const HavePicture = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  margin: auto;
  position: absolute;
  z-index: 7;
`;
const ImgFile = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().img)`
  width: 100%;
  height: 100%;
  object-fit: cover;
`;
const DivCatalogOptions = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  border-style: solid;
  border-width: 1px;
  border-radius: 10px;
  background: white;
  position: absolute;
  top: 110%;
  margin: auto;
  width: 100%;
  z-index: 20;
  display: ${(props)=>props.show === "false" && "none"
};
  overflow: hidden;
`;
const PoptionCatalogue = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().p)`
  padding: 0;
  margin: 0;
  padding-left: 10px;
  &:hover {
    background: grey;
    cursor: pointer;
    color: white;
  }
`;
const DivBenefitOpcion = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  border-style: solid;
  border-width: 1px;
  border-radius: 10px;
  height: 2rem;
  margin-bottom: 10px;
  background: #f1f1f1;
  display: flex;
  align-items: center;
  padding-left: 15px;
  padding-right: 15px;
  justify-content: space-between;
`;
const Pbenefit = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().p)`
  margin: 0;
  padding: 0;
`;
const DivImgBenefitOption = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  cursor: pointer;
  height: 70%;
  margin-left: 10px;
`;
const ImgBenefit = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().img)`
  height: 100%;
  width: auto;
`;
const DivCheck = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  display: flex;
  align-items: center;
`;
const InputCheck = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().input)``;


/***/ }),

/***/ 8663:
/***/ ((module) => {

module.exports = "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIj8+PHN2ZyBmaWxsPSIjMDAwMDAwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciICB2aWV3Qm94PSIwIDAgMjQgMjQiIHdpZHRoPSIyNHB4IiBoZWlnaHQ9IjI0cHgiPiAgICA8cGF0aCBkPSJNIDE4LjQxNDA2MiAyIEMgMTguMTU4MTg4IDIgMTcuOTAyMDMxIDIuMDk3NDY4NyAxNy43MDcwMzEgMi4yOTI5Njg4IEwgMTYgNCBMIDIwIDggTCAyMS43MDcwMzEgNi4yOTI5Njg4IEMgMjIuMDk4MDMxIDUuOTAxOTY4NyAyMi4wOTgwMzEgNS4yNjg5MDYzIDIxLjcwNzAzMSA0Ljg3ODkwNjIgTCAxOS4xMjEwOTQgMi4yOTI5Njg4IEMgMTguOTI1NTk0IDIuMDk3NDY4NyAxOC42Njk5MzcgMiAxOC40MTQwNjIgMiB6IE0gMTQuNSA1LjUgTCAzIDE3IEwgMyAyMSBMIDcgMjEgTCAxOC41IDkuNSBMIDE0LjUgNS41IHoiLz48L3N2Zz4="

/***/ }),

/***/ 1842:
/***/ ((module) => {

module.exports = "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIj8+PHN2ZyBmaWxsPSIjMDAwMDAwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciICB2aWV3Qm94PSIwIDAgMjQgMjQiIHdpZHRoPSIyNHB4IiBoZWlnaHQ9IjI0cHgiPiAgICA8cGF0aCBkPSJNMTIsMkM2LjQ3NywyLDIsNi40NzcsMiwxMnM0LjQ3NywxMCwxMCwxMHMxMC00LjQ3NywxMC0xMFMxNy41MjMsMiwxMiwyeiBNMTcsMTNoLTR2NGgtMnYtNEg3di0yaDRWN2gydjRoNFYxM3oiLz48L3N2Zz4="

/***/ }),

/***/ 3006:
/***/ ((module) => {

module.exports = "data:image/svg+xml;base64,PHN2ZyBmaWxsPSIjMDAwMDAwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciICB2aWV3Qm94PSIwIDAgMjQgMjQiIHdpZHRoPSIyNHB4IiBoZWlnaHQ9IjI0cHgiPjxwYXRoIGQ9Ik0gMTAgMiBMIDkgMyBMIDMgMyBMIDMgNSBMIDIxIDUgTCAyMSAzIEwgMTUgMyBMIDE0IDIgTCAxMCAyIHogTSA0LjM2NTIzNDQgNyBMIDUuODkyNTc4MSAyMC4yNjM2NzIgQyA2LjAyNDU3ODEgMjEuMjUzNjcyIDYuODc3IDIyIDcuODc1IDIyIEwgMTYuMTIzMDQ3IDIyIEMgMTcuMTIxMDQ3IDIyIDE3Ljk3NDQyMiAyMS4yNTQ4NTkgMTguMTA3NDIyIDIwLjI1NTg1OSBMIDE5LjYzNDc2NiA3IEwgNC4zNjUyMzQ0IDcgeiIvPjwvc3ZnPg=="

/***/ }),

/***/ 7756:
/***/ ((module) => {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAMAAADDpiTIAAAAA3NCSVQICAjb4U/gAAAACXBIWXMAABFfAAARXwH207MgAAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAAKJQTFRF////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA6C3cNgAAADV0Uk5TAAEEBQkKDBESFSYuLzM0OT5DWmJwcnN/gYWOkZqfpamys7W2vcHDxMbP0N7h5Ojr+fr7/f4xqDu7AAALJklEQVQYGe3BB5aiahgE0MLUKOacc06AWvvf2tvAnHemu4Xvx6l7gX9RqdYeztf78yWMovBy3q/nw3atBPkHFFqj7Y1/dNuOWgXI58o1B7uI/yvaDZo5yCcKxnf+lfs4gHyYcvfEbzh1y5DPUZnF/KZ4VoF8huriyR94LqqQ7Kuv+GOrOiTb/OmLv/Ca+pDs8johfynseJCMCg58g0MAyaRezLeIe5Ds8Zd8m6UPyZjGlW90bUAypf/gWz36kOzwJny7iQfJiPycCZjnIZlQ3DARmyIkA76OTMjxC+K84pGJORYhjstvmKBNHuI0b85EzT2IyyZM2ATisD4T14c4q/Fg4h4NiKP8K1Nw9SFuWjIVS4iTekxJD+KgIGZK4gDiHO/A1Bw8iGs6TFEH4hg/ZIpCH+KWKVM1hTil/mKqXnWIS1ZM2QrikCpTV4W4Y8HULSDOqDyZumcF4ooZDcwgjijHNBCXIW7o0kQX4oYTTZwgTghoJIC4YEwjY4gDcncauecg9po004TYG9DMAGJvRzM7iLlCRDNRAWKtRUMtiLURDY0g1rY0tIVYu9HQDWKsRFMliK0aTdUgtto01YbYGtLUEGJrTlNziK01Ta0htvY0tYfYOtPUGWLrQlMXiK2QpkKIrYimIoitiKYiiK2QpkKIrQtNXSC2zjR1htja09QeYmtNU2uIrTlNzSG2hjQ1hNhq01QbYqtGUzWIrRJNlSDGbjR0g1jb0tAWYm1EQyOItRYNtSDWChHNRAWIuR3N7CD2BjQzgNhr0kwTYi93p5F7DuKAMY2MIS4IaCSAOOFEEyeIG7o00YW4oRzTQFyGOGJGAzOIKypPpu5ZgThjwdQtIO6oMnVViENWTNkK4pL6i6l61SFOmTJVU4hb/JApCn2IYzpMUQfiGu/A1Bw8iHOCmCmJA4iDekxJD+KkJVOxhLjJvzIFVx/iqMaDiXs0IM7qM3F9iMMmTNgE4jJvzkTNPYjT8hsmaJOHOK54ZGKORYjzvo5MyPELkgHFDROxKUIyIT9nAuZ5SEZ4E77dxINkR//Bt3r0IZnSuPKNrg1IxvhLvs3Sh2RPL+ZbxD1IJgUHvsEhgGSU1wn5S2HHg2SXP33xF15TH5Jt9RV/bFWHZF918eQPPBdVyGeozGJ+UzyrQD5HuXviN5y6ZciHCcZ3/pX7OIB8olxzsIv4v6LdoJmDfK5Ca7S98Y9u21GrAPkHlGrt4Xy9P1/CKAov5/16PmzXShARERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERGRv1WqtYfz9f58CaMovJz36/mwXStB/gGF1mh74x/dtqNWAfK5cs3BLuL/inaDZg7yiYLxnX/lPg4gH6bcPfEbTt0y5HNUZjG/KZ5VIJ+hunjyB56LKiT76iv+2KoOyTZ/+uIvvKY+JLu8TshfCjseJKOCA9/gEEAyqRfzLeIeJHv8Jd9m6UMypnHlG10bkEzpP/hWjz4kO7wJ327iQTIiP2cC5nlIJhQ3TMSmCMmAryMTcvyCOK94ZGKORYjj8hsmaJOHOM2bM1FzD+KyCRM2gTisz8T1Ic5qPJi4RwPiKP/KFFx9iJuWTMUS4qQeU9KDOCiImZI4gDjHOzA1Bw/img5T1IE4xg+ZotCHuGXKVE0hTqm/mKpXHeKSFVO2gjikytRVIe5YMHULiDMqT6buWYG4YkYDM4gjyjENxGWIG7o00YW44UQTJ4gTAhoJIC4Y08gY4oDcnUbuOYi9Js00IfYGNDOA2NvRzA5irhDRTFSAWGvRUAtibURDI4i1LQ1tIdZuNHSDGCvRVAliq0ZTNYitNk21IbaGNDWE2JrT1Bxia01Ta4itPU3tIbbONHWG2LrQ1AViK6SpEGIroqkIYiuiqQhiK6SpEGLrQlMXiK0zTZ0htvY0tYfYWtPUGmJrTlNziK0hTQ0htto01YbYqtFUDWKrRFMliLEbDd0g1rY0tIVYG9HQCGKtRUMtiLVCRDNRAWJuRzM7iL0BzQwg9po004TYy91p5J6DOGBMI2OICwIaCSBOONHECeKGLk10IW4oxzQQlyGOmNHADOKKypOpe1YgzlgwdQuIO6pMXRXikBVTtoK4pP5iql51iFOmTNUU4hY/ZIpCH+KYDlPUgbjGOzA1Bw/inCBmSuIA4qAeU9KDOGnJVCwhbvKvTMHVhziq8WDiHg2Is/pMXB/isAkTNoG4zJszUXMP4rT8hgna5CGOKx6ZmGMR4ryvIxNy/IJkQHHDRGyKkEzIz5mAeR6SEd6EbzfxINnRf/CtHn1IpjSufKNrA5Ix/pJvs/Qh2dOL+RZxD5JJwYFvcAggGeV1Qv5S2PEg2eVPX/yF19SHZFt9xR9b1SHZV108+QPPRRXyGSqzmN8UzyqQz1HunvgNp24Z8mGC8Z1/5T4OIJ8o1xzsIv6vaDdo5iCfq9AabW/8o9t21CpA/gGlWns4X+/PlzCKwst5v54P27USRERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERORvlWrt4Xy9P1/CKAov5/16PmzXSpB/QKE12t74R7ftqFWAfK5cc7CL+L+i3aCZg3yiYHznX7mPA8iHKXdP/IZTtwz5HJVZzG+KZxXIZ6gunvyB56IKyb76ij+2qkOyzZ+++AuvqQ/JLq8T8pfCjgfJqODANzgEkEzqxXyLuAfJHn/Jt1n6kIxpXPlG1wYkU/oPvtWjD8kOb8K3m3iQjMjPmYB5HpIJxQ0TsSlCMuDryIQcvyDOKx6ZmGMR4rj8hgna5CFO8+ZM1NyDuGzChE0gDuszcX2IsxoPJu7RgDjKvzIFVx/ipiVTsYQ4qceU9CAOCmKmJA4gzvEOTM3Bg7imwxR1II7xQ6Yo9CFumTJVU4hT6i+m6lWHuGTFlK0gDqkydVWIOxZM3QLijMqTqXtWIK6Y0cAM4ohyTANxGeKGLk10IW440cQJ4oSARgKIC8Y0MoY4IHenkXsOYq9JM02IvQHNDCD2djSzg5grRDQTFSDWWjTUglgb0dAIYm1LQ1uItRsN3SDGSjRVgtiq0VQNYqtNU22IrSFNDSG25jQ1h9ha09QaYmtPU3uIrTNNnSG2LjR1gdgKaSqE2IpoKoLYimgqgtgKaSqE2LrQ1AVi60xTZ4itPU3tIbbWNLWG2JrT1Bxia0hTQ4itNk21IbZqNFWD2CrRVAli7EZDN4i1LQ1tIdZGNDSCWGvRUAtirRDRTFSAmNvRzA5ib0AzA4i9Js00IfZydxq55yAOGNPIGOKCgEYCiBNONHGCuKFLE12IG8oxDcRliCNmNDCDuKLyZOqeFYgzFkzdAuKOKlNXhThkxZStIC6pv5iqVx3ilClTNYW4xQ+ZotCHOKbDFHUgrvEOTM3BgzgniJmSOIA4qMeU9CBOWjIVS4ib/CtTcPUhjmo8mLhHA+KsPhPXhzhswoRNIC7z5kzU3IM4Lb9hgjZ5iOOKRybmWIQ47+vIhBy/IBlQ3DARmyIkE/JzJmCeh2SEN+HbTTxIdvQffKtHH5IpjSvf6NqAZIy/5NssfUj29GK+RdyDZFJw4BscAkhGeZ2QvxR2PEh2+dMXf+E19SHZVl/xx1Z1SPZVF0/+wHNRhXyGyizmN8WzCuRzlLsnfsOpW4Z8mGB851+5jwPIJ8o1B7uI/yvaDZo5yOcqtEbbG//oth21CpB/QKnWHs7X+/MljKLwct6v58N2rYR/0X/c+B8ypl4bhgAAAABJRU5ErkJggg=="

/***/ })

};
;