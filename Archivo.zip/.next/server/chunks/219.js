"use strict";
exports.id = 219;
exports.ids = [219];
exports.modules = {

/***/ 3219:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const URL = `${"https://backend.fustadesign.com/api/v1/"}`;
const useAxiosPost = (endpoint, options)=>{
    const { 0: isLoading , 1: setisLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const Post = async (dataBody, headers)=>{
        try {
            var ref, ref1;
            const resp = await axios__WEBPACK_IMPORTED_MODULE_0___default()({
                method: "post",
                url: `${URL}${endpoint}`,
                headers: headers,
                data: dataBody
            });
            if (options === null || options === void 0 ? void 0 : (ref = options.completeInterceptor) === null || ref === void 0 ? void 0 : ref.action) {
                setisLoading(true);
                options.completeInterceptor.action(resp);
            }
            if (options === null || options === void 0 ? void 0 : (ref1 = options.completeInterceptor) === null || ref1 === void 0 ? void 0 : ref1.message) {
                var ref2;
                console.log(options === null || options === void 0 ? void 0 : (ref2 = options.completeInterceptor) === null || ref2 === void 0 ? void 0 : ref2.message);
            }
        } catch (err) {
            var ref3, ref4;
            if (options === null || options === void 0 ? void 0 : (ref3 = options.errorInterceptor) === null || ref3 === void 0 ? void 0 : ref3.action) {
                setisLoading(true);
                options.errorInterceptor.action();
            }
            if (options === null || options === void 0 ? void 0 : (ref4 = options.errorInterceptor) === null || ref4 === void 0 ? void 0 : ref4.message) {
                var ref5;
                console.log(options === null || options === void 0 ? void 0 : (ref5 = options.errorInterceptor) === null || ref5 === void 0 ? void 0 : ref5.message);
            }
        }
    };
    return {
        Post,
        isLoading
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useAxiosPost);


/***/ })

};
;