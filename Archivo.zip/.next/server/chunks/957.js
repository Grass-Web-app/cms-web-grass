"use strict";
exports.id = 957;
exports.ids = [957];
exports.modules = {

/***/ 3844:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "t7": () => (/* binding */ DarkMode),
/* harmony export */   "WU": () => (/* binding */ Token),
/* harmony export */   "_1": () => (/* binding */ handleToken),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports coockiesNames, CookiesSlice, handleMode, handleEraseCookies */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9915);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_1__]);
js_cookie__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];


const projectName = "cms-fusta";
const coockiesNames = {
    darkMode: `${projectName}Mode`,
    token: `${projectName}Token`,
    currentUser: `${projectName}User`,
    stores: `${projectName}Stores`
};
function createDarkModeCookie() {
    js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].set(coockiesNames.darkMode, `${false}`);
    return false;
}
function createTokenCookie() {
    js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].set(coockiesNames.token, JSON.stringify({
        access: "",
        refresh: ""
    }));
    return {
        access: "",
        refresh: ""
    };
}
function initCookies(type) {
    switch(type){
        case coockiesNames.darkMode:
            var ref;
            return js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get(coockiesNames.darkMode) ? ((ref = js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get(coockiesNames.darkMode)) === null || ref === void 0 ? void 0 : ref.toString()) === "true" ? true : false : createDarkModeCookie();
        case coockiesNames.token:
            return js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get(coockiesNames.token) ? JSON.parse(js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get(coockiesNames.token)) : createTokenCookie();
        default:
            break;
    }
}
const initialState = {
    darkMode: initCookies(coockiesNames.darkMode),
    token: initCookies(coockiesNames.token)
};
const CookiesSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "Cookies",
    initialState,
    reducers: {
        handleMode: (state, action)=>{
            state.darkMode = action.payload;
            js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].set(coockiesNames.darkMode, `${action.payload}`);
        },
        handleToken: (state, action)=>{
            state.token = action.payload;
            action.payload !== undefined && js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].set(coockiesNames.token, JSON.stringify(action.payload));
        },
        handleEraseCookies: ()=>{
            js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].remove(coockiesNames.token);
            js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].remove(coockiesNames.currentUser);
            js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].remove(coockiesNames.stores);
        }
    }
});
const DarkMode = (state)=>state.cookies.darkMode
;
const Token = (state)=>state.cookies.token
;
//export const selectUser = (state: AppState) => state.cookies.currentUser;
//export const InnerSize = (state: AppState) => state.cookies.innerSize;
const { handleMode , //handleCurrentUser,
handleEraseCookies , //handleInnerSize,
handleToken ,  } = CookiesSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CookiesSlice.reducer);

});

/***/ }),

/***/ 4266:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "sw": () => (/* binding */ HandleMenuMobile),
  "FA": () => (/* binding */ MenuMobileBurguer),
  "ZP": () => (/* binding */ ReduxSlices_counterSlice)
});

// UNUSED EXPORTS: counterSlice, decrement, increment, incrementAsync, incrementByAmount, incrementIfOdd, selectCount

// EXTERNAL MODULE: external "@reduxjs/toolkit"
var toolkit_ = __webpack_require__(5184);
;// CONCATENATED MODULE: ./src/Views/counter/counterAPI.ts
async function fetchCount(amount = 1) {
    const response = await fetch('/api/counter', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            amount
        })
    });
    const result = await response.json();
    return result;
}

;// CONCATENATED MODULE: ./src/app/components/ReduxSlices/counterSlice.ts


const initialState = {
    value: 1,
    status: "idle",
    menu: false
};
// The function below is called a thunk and allows us to perform async logic. It
// can be dispatched like a regular action: `dispatch(incrementAsync(10))`. This
// will call the thunk with the `dispatch` function as the first argument. Async
// code can then be executed and other actions can be dispatched. Thunks are
// typically used to make async requests.
const incrementAsync = (0,toolkit_.createAsyncThunk)("counter/fetchCount", async (amount)=>{
    const response = await fetchCount(amount);
    // The value we return becomes the `fulfilled` action payload
    return response.data;
});
const counterSlice = (0,toolkit_.createSlice)({
    name: "counter",
    initialState,
    // The `reducers` field lets us define reducers and generate associated actions
    reducers: {
        increment: (state)=>{
            // Redux Toolkit allows us to write "mutating" logic in reducers. It
            // doesn't actually mutate the state because it uses the Immer library,
            // which detects changes to a "draft state" and produces a brand new
            // immutable state based off those changes
            state.value += 1;
        },
        decrement: (state)=>{
            state.value !== 0 ? state.value -= 1 : state.value = 0;
        },
        // Use the PayloadAction type to declare the contents of `action.payload`
        incrementByAmount: (state, action)=>{
            state.value += action.payload;
        },
        HandleMenuMobile: (state)=>{
            state.menu = !state.menu;
        }
    },
    // The `extraReducers` field lets the slice handle actions defined elsewhere,
    // including actions generated by createAsyncThunk or in other slices.
    extraReducers: (builder)=>{
        builder.addCase(incrementAsync.pending, (state)=>{
            state.status = "loading";
        }).addCase(incrementAsync.fulfilled, (state, action)=>{
            state.status = "idle";
            state.value += action.payload;
        });
    }
});
const { increment , decrement , incrementByAmount , HandleMenuMobile  } = counterSlice.actions;
// The function below is called a selector and allows us to select a value from
// the state. Selectors can also be defined inline where they're used instead of
// in the slice file. For example: `useSelector((state: RootState) => state.counter.value)`
const selectCount = (state)=>state.counter.value
;
const MenuMobileBurguer = (state)=>state.counter.menu
;
// We can also write thunks by hand, which may contain both sync and async logic.
// Here's an example of conditionally dispatching actions based on current state.
const incrementIfOdd = (amount)=>(dispatch, getState)=>{
        const currentValue = selectCount(getState());
        if (currentValue % 2 === 1) {
            dispatch(incrementByAmount(amount));
        }
    }
;
/* harmony default export */ const ReduxSlices_counterSlice = (counterSlice.reducer);


/***/ }),

/***/ 7353:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export makeStore */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ReduxSlices_counterSlice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4266);
/* harmony import */ var _components_ReduxSlices_CookiesSlice__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3844);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ReduxSlices_CookiesSlice__WEBPACK_IMPORTED_MODULE_2__]);
_components_ReduxSlices_CookiesSlice__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];



function makeStore() {
    return (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({
        reducer: {
            cookies: _components_ReduxSlices_CookiesSlice__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP,
            counter: _components_ReduxSlices_counterSlice__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP
        }
    });
}
const store = makeStore();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (store);

});

/***/ }),

/***/ 2957:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "prefix": () => (/* binding */ prefix),
/* harmony export */   "default": () => (/* binding */ MyApp)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _app_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7353);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_app_store__WEBPACK_IMPORTED_MODULE_2__]);
_app_store__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];




const prefix = process.env.NEXT_PUBLIC_BASE_PATH || "";
function MyApp({ Component , pageProps  }) {
    function SafeHydrate({ children  }) {
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            suppressHydrationWarning: true,
            children:  true ? null : 0
        }));
    }
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_redux__WEBPACK_IMPORTED_MODULE_1__.Provider, {
        store: _app_store__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SafeHydrate, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                ...pageProps
            })
        })
    }));
};

});

/***/ })

};
;