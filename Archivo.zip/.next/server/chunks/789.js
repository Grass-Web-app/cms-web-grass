"use strict";
exports.id = 789;
exports.ids = [789];
exports.modules = {

/***/ 5673:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TL": () => (/* binding */ useAppDispatch),
/* harmony export */   "CG": () => (/* binding */ useAppSelector)
/* harmony export */ });
/* unused harmony exports useForm, useInterval */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);


/*
Redux hooks!!!!! dont touch it!
*/ const useForm = (defaultValues)=>(handler)=>async (event)=>{
            event.preventDefault();
            event.persist();
            const form = event.target;
            const elements = Array.from(form.elements);
            const data = elements.filter((element)=>element.hasAttribute('name')
            ).reduce((object, element)=>({
                    ...object,
                    [`${element.getAttribute('name')}`]: element.value
                })
            , defaultValues);
            await handler(data);
            form.reset();
        }
;
// https://overreacted.io/making-setinterval-declarative-with-react-hooks/
const useInterval = (callback, delay)=>{
    const savedCallback = useRef();
    useEffect(()=>{
        savedCallback.current = callback;
    }, [
        callback
    ]);
    useEffect(()=>{
        const handler = (...args)=>{
            var ref;
            return (ref = savedCallback.current) === null || ref === void 0 ? void 0 : ref.call(savedCallback, ...args);
        };
        if (delay !== null) {
            const id = setInterval(handler, delay);
            return ()=>clearInterval(id)
            ;
        }
    }, [
        delay
    ]);
};
// Use throughout your app instead of plain `useDispatch` and `useSelector`
const useAppDispatch = ()=>(0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)()
;
const useAppSelector = react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector;


/***/ }),

/***/ 3436:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const URL = `${"https://backend.fustadesign.com/api/v1/"}`;
const useAxiosGet = (endpoint, options)=>{
    const { 0: isLoading , 1: setisLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const Get = async (token)=>{
        try {
            var ref, ref1;
            const resp = await axios__WEBPACK_IMPORTED_MODULE_1___default()({
                method: "get",
                url: `${URL}${endpoint}`,
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            if (options === null || options === void 0 ? void 0 : (ref = options.completeInterceptor) === null || ref === void 0 ? void 0 : ref.action) {
                setisLoading(true);
                options.completeInterceptor.action(resp);
            }
            if (options === null || options === void 0 ? void 0 : (ref1 = options.completeInterceptor) === null || ref1 === void 0 ? void 0 : ref1.message) {
                var ref2;
                console.log(options === null || options === void 0 ? void 0 : (ref2 = options.completeInterceptor) === null || ref2 === void 0 ? void 0 : ref2.message);
            }
        } catch (err) {
            var ref3, ref4;
            if (options === null || options === void 0 ? void 0 : (ref3 = options.errorInterceptor) === null || ref3 === void 0 ? void 0 : ref3.action) {
                setisLoading(true);
                options.errorInterceptor.action();
            }
            if (options === null || options === void 0 ? void 0 : (ref4 = options.errorInterceptor) === null || ref4 === void 0 ? void 0 : ref4.message) {
                var ref5;
                console.log(options === null || options === void 0 ? void 0 : (ref5 = options.errorInterceptor) === null || ref5 === void 0 ? void 0 : ref5.message);
            }
        }
    };
    return {
        Get,
        isLoading
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useAxiosGet);


/***/ })

};
;