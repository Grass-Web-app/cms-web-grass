exports.id = 372;
exports.ids = [372];
exports.modules = {

/***/ 4415:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_createGlobalStyles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7609);
/* harmony import */ var _Reduxhooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5673);
/* harmony import */ var _ReduxSlices_CookiesSlice__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3844);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ReduxSlices_CookiesSlice__WEBPACK_IMPORTED_MODULE_3__]);
_ReduxSlices_CookiesSlice__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];




const BodyColorChange = ()=>{
    const darkMode = (0,_Reduxhooks__WEBPACK_IMPORTED_MODULE_2__/* .useAppSelector */ .CG)(_ReduxSlices_CookiesSlice__WEBPACK_IMPORTED_MODULE_3__/* .DarkMode */ .t7);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("style", {
        children: `body {  background-color: ${darkMode.toString() === "true" ? _styles_createGlobalStyles__WEBPACK_IMPORTED_MODULE_1__/* .BackSecondary */ .HW : _styles_createGlobalStyles__WEBPACK_IMPORTED_MODULE_1__/* .BackPrimary */ .Qs} ; }`
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BodyColorChange);

});

/***/ }),

/***/ 1386:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pages_app__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2957);
/* harmony import */ var _Reduxhooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5673);
/* harmony import */ var _ReduxSlices_CookiesSlice__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3844);
/* harmony import */ var _ReduxSlices_counterSlice__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4266);
/* harmony import */ var _styledleftnav__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4068);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_app__WEBPACK_IMPORTED_MODULE_3__, _ReduxSlices_CookiesSlice__WEBPACK_IMPORTED_MODULE_5__]);
([_pages_app__WEBPACK_IMPORTED_MODULE_3__, _ReduxSlices_CookiesSlice__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);








const OptionsNAvigation = [
    {
        title: "Catalogo",
        icon: __webpack_require__(5238),
        link: "/catalog"
    },
    {
        title: "Engineered",
        icon: __webpack_require__(257),
        link: "/engineered"
    },
    {
        title: "Parallax",
        icon: __webpack_require__(6872),
        link: "/parallax"
    },
    {
        title: "Carousel",
        icon: __webpack_require__(1147),
        link: "/carousel"
    },
    {
        title: "Cards",
        icon: __webpack_require__(5672),
        link: "/cards"
    },
    {
        title: "Footer",
        icon: __webpack_require__(6670),
        link: "/footer"
    }, 
];
const LeftNav = (props)=>{
    const { area , show  } = props;
    const dispatch = (0,_Reduxhooks__WEBPACK_IMPORTED_MODULE_4__/* .useAppDispatch */ .TL)();
    const { pathname , push  } = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const HandleNav = (path)=>{
        push(path);
    };
    const handleCloseMenu = ()=>{
        dispatch((0,_ReduxSlices_counterSlice__WEBPACK_IMPORTED_MODULE_6__/* .HandleMenuMobile */ .sw)());
    };
    const ClickToLink = (link)=>{
        handleCloseMenu();
        HandleNav(link);
    };
    const CloseSession = ()=>{
        dispatch((0,_ReduxSlices_CookiesSlice__WEBPACK_IMPORTED_MODULE_5__/* .handleToken */ ._1)({
            access: "",
            refresh: ""
        }));
        handleCloseMenu();
        push("/login");
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styledleftnav__WEBPACK_IMPORTED_MODULE_7__/* .DivLeftNavContainer */ .yq, {
        area: area,
        show: show.toString(),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledleftnav__WEBPACK_IMPORTED_MODULE_7__/* .DivImgLogo */ .US, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledleftnav__WEBPACK_IMPORTED_MODULE_7__/* .ImgLogo */ .X, {
                    alt: "logo",
                    src: _pages_app__WEBPACK_IMPORTED_MODULE_3__.prefix + __webpack_require__(1428)
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledleftnav__WEBPACK_IMPORTED_MODULE_7__/* .CloseMenu */ .tf, {
                onClick: handleCloseMenu,
                children: "X"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledleftnav__WEBPACK_IMPORTED_MODULE_7__/* .DivOptions */ .tE, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledleftnav__WEBPACK_IMPORTED_MODULE_7__/* .DivOptionsCenter */ .IN, {
                    children: OptionsNAvigation.map((item, index)=>{
                        const { title , icon , link  } = item;
                        let background = false;
                        if (pathname.includes(link)) background = true;
                        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styledleftnav__WEBPACK_IMPORTED_MODULE_7__/* .DivTextOption */ .Gp, {
                            onClick: ()=>ClickToLink(link)
                            ,
                            bg: background.toString(),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledleftnav__WEBPACK_IMPORTED_MODULE_7__/* .DivImgIcon */ .dH, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledleftnav__WEBPACK_IMPORTED_MODULE_7__/* .ImgIcon */ .EV, {
                                        alt: "icon",
                                        src: icon
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledleftnav__WEBPACK_IMPORTED_MODULE_7__/* .PText */ .T2, {
                                    children: title
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledleftnav__WEBPACK_IMPORTED_MODULE_7__/* .DivImgArrow */ .Q8, {
                                    children: !background && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledleftnav__WEBPACK_IMPORTED_MODULE_7__/* .ImgRightArrow */ .Vo, {
                                        alt: "arrow",
                                        src: __webpack_require__(1186)
                                    })
                                })
                            ]
                        }, index));
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledleftnav__WEBPACK_IMPORTED_MODULE_7__/* .PCloseSession */ .jN, {
                onClick: CloseSession,
                children: "Cerrar sesion"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styledleftnav__WEBPACK_IMPORTED_MODULE_7__/* .DivMarcasText */ .Ef, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledleftnav__WEBPACK_IMPORTED_MODULE_7__/* .PMarkTextq */ .Ap, {
                        children: "Fustadesing"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledleftnav__WEBPACK_IMPORTED_MODULE_7__/* .PMarkTextq */ .Ap, {
                        children: "All right reserved"
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LeftNav);

});

/***/ }),

/***/ 4068:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "yq": () => (/* binding */ DivLeftNavContainer),
/* harmony export */   "tf": () => (/* binding */ CloseMenu),
/* harmony export */   "US": () => (/* binding */ DivImgLogo),
/* harmony export */   "X": () => (/* binding */ ImgLogo),
/* harmony export */   "tE": () => (/* binding */ DivOptions),
/* harmony export */   "Gp": () => (/* binding */ DivTextOption),
/* harmony export */   "T2": () => (/* binding */ PText),
/* harmony export */   "dH": () => (/* binding */ DivImgIcon),
/* harmony export */   "Q8": () => (/* binding */ DivImgArrow),
/* harmony export */   "Vo": () => (/* binding */ ImgRightArrow),
/* harmony export */   "EV": () => (/* binding */ ImgIcon),
/* harmony export */   "IN": () => (/* binding */ DivOptionsCenter),
/* harmony export */   "Ef": () => (/* binding */ DivMarcasText),
/* harmony export */   "Ap": () => (/* binding */ PMarkTextq),
/* harmony export */   "jN": () => (/* binding */ PCloseSession)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const DivLeftNavContainer = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  grid-area: ${(props)=>props.area
};
  background: #c7e6fa;
  display: ${(props)=>props.show === "false" ? "none" : "flex"
};
  height: 100%;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  position: relative;
  padding-top: 5%;
  padding-bottom: 5%;
  @media (min-width: 1020px) {
    display: flex;
  }
`;
const CloseMenu = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().button)`
  position: absolute;
  border: none;
  background: transparent;
  right: 16px;
  top: 16px;
  margin: auto;
  @media (min-width: 1020px) {
    display: none;
  }
`;
const DivImgLogo = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  width: 50%;
`;
const ImgLogo = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().img)`
  width: 100%;
  height: auto;
`;
const DivOptions = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  width: 100%;
  height: 50%;
  display: flex;
  flex-direction: column;
  align-items: center;
`;
const DivTextOption = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  border-radius: 50px;
  display: flex;
  background: ${(props)=>props.bg === "true" ? "#C7E6FA" : "white"
};
  cursor: pointer;
  justify-content: space-around;
`;
const PText = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().p)`
  margin-left: 5%;
  font-size: 1rem;
`;
const DivImgIcon = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  display: flex;
  align-items: center;
  margin-left: 5%;
`;
const DivImgArrow = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  height: 100%;
  transform: rotate(180deg);
  display: flex;
  align-items: center;
`;
const ImgRightArrow = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().img)`
  height: 45%;
  width: auto;
`;
const ImgIcon = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().img)`
  width: 100%;
  height: auto;
`;
const DivOptionsCenter = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  width: 70%;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
`;
const DivMarcasText = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  width: 100%;
`;
const PMarkTextq = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().p)`
  width: 100%;
  text-align: center;
  margin: 0;
`;
const PCloseSession = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().p)`
  text-align: center;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  padding-right: 10px;
  padding-left: 10px;
  border-radius: 1000px;
  background: #124759;
  color: white;
  @media (min-width: 1020px) {
    display: none;
  }
`;


/***/ }),

/***/ 9797:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8922);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_hot_toast__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pages_app__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2957);
/* harmony import */ var _Reduxhooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5673);
/* harmony import */ var _ReduxSlices_CookiesSlice__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3844);
/* harmony import */ var _ReduxSlices_counterSlice__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4266);
/* harmony import */ var _styledheader__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3680);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_app__WEBPACK_IMPORTED_MODULE_4__, _ReduxSlices_CookiesSlice__WEBPACK_IMPORTED_MODULE_6__]);
([_pages_app__WEBPACK_IMPORTED_MODULE_4__, _ReduxSlices_CookiesSlice__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);









const Header = (props)=>{
    const dispatch = (0,_Reduxhooks__WEBPACK_IMPORTED_MODULE_5__/* .useAppDispatch */ .TL)();
    const { area  } = props;
    const { push  } = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const { 0: arrow , 1: setArrow  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: options , 1: setOptions  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const handleOptions = ()=>{
        setArrow(!arrow);
        setOptions(!options);
    };
    const selectOptions = (option)=>{
        switch(option){
            case "closeSesion":
                dispatch((0,_ReduxSlices_CookiesSlice__WEBPACK_IMPORTED_MODULE_6__/* .handleToken */ ._1)({
                    access: "",
                    refresh: ""
                }));
                push("/login");
                break;
            default:
                close();
                break;
        }
    };
    const close = ()=>{
        setArrow(false);
        setOptions(false);
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styledheader__WEBPACK_IMPORTED_MODULE_8__/* .DivHeaderContainer */ .hx, {
        area: area,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hot_toast__WEBPACK_IMPORTED_MODULE_3__.Toaster, {
                position: "top-right"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledheader__WEBPACK_IMPORTED_MODULE_8__/* .DivTitle */ .Gd, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledheader__WEBPACK_IMPORTED_MODULE_8__/* .Title */ .Dx, {
                    children: "Bienvenido al cms"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledheader__WEBPACK_IMPORTED_MODULE_8__/* .PMobile */ .m8, {
                children: "Bienvenido al cms"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledheader__WEBPACK_IMPORTED_MODULE_8__/* .DivBurguer */ .QU, {
                onClick: ()=>dispatch((0,_ReduxSlices_counterSlice__WEBPACK_IMPORTED_MODULE_7__/* .HandleMenuMobile */ .sw)())
                ,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    style: {
                        width: "100%",
                        height: "100%"
                    },
                    src: __webpack_require__(979)
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styledheader__WEBPACK_IMPORTED_MODULE_8__/* .DivUsuarioAvatar */ .eG, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledheader__WEBPACK_IMPORTED_MODULE_8__/* .PUser */ .Kn, {
                        children: "Fustadesing"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styledheader__WEBPACK_IMPORTED_MODULE_8__/* .DivUserArrow */ .Oy, {
                        onClick: handleOptions,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledheader__WEBPACK_IMPORTED_MODULE_8__/* .DivImgAvatar */ .V, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledheader__WEBPACK_IMPORTED_MODULE_8__/* .ImgAvatar */ .Ed, {
                                    alt: "avatar",
                                    src: _pages_app__WEBPACK_IMPORTED_MODULE_4__.prefix + __webpack_require__(368)
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledheader__WEBPACK_IMPORTED_MODULE_8__/* .DivArrow */ .ty, {
                                state: arrow.toString(),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledheader__WEBPACK_IMPORTED_MODULE_8__/* .ImgArrow */ .OY, {
                                    alr: "arrow",
                                    src: __webpack_require__(6103)
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styledheader__WEBPACK_IMPORTED_MODULE_8__/* .DivOptions */ .tE, {
                        show: options.toString(),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledheader__WEBPACK_IMPORTED_MODULE_8__/* .Poptions */ .D3, {
                                onClick: ()=>selectOptions("cuenta")
                                ,
                                children: "Ver mi cuenta"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styledheader__WEBPACK_IMPORTED_MODULE_8__/* .Poptions */ .D3, {
                                onClick: ()=>selectOptions("closeSesion")
                                ,
                                children: "Cerrar sesion"
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);

});

/***/ }),

/***/ 3680:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "hx": () => (/* binding */ DivHeaderContainer),
/* harmony export */   "Gd": () => (/* binding */ DivTitle),
/* harmony export */   "m8": () => (/* binding */ PMobile),
/* harmony export */   "QU": () => (/* binding */ DivBurguer),
/* harmony export */   "Dx": () => (/* binding */ Title),
/* harmony export */   "V": () => (/* binding */ DivImgAvatar),
/* harmony export */   "Ed": () => (/* binding */ ImgAvatar),
/* harmony export */   "eG": () => (/* binding */ DivUsuarioAvatar),
/* harmony export */   "Kn": () => (/* binding */ PUser),
/* harmony export */   "ty": () => (/* binding */ DivArrow),
/* harmony export */   "OY": () => (/* binding */ ImgArrow),
/* harmony export */   "Oy": () => (/* binding */ DivUserArrow),
/* harmony export */   "tE": () => (/* binding */ DivOptions),
/* harmony export */   "D3": () => (/* binding */ Poptions)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const DivHeaderContainer = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  grid-area: ${(props)=>props.area
};
  display: flex;
  justify-content: space-between;
  padding-left: 1%;
  padding-right: 1%;
  align-items: center;
  background: #c7e6fa;
  box-shadow: 0px 2px 5px 2px rgba(0, 0, 0, 0.2);
`;
const DivTitle = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  display: none;
  @media (min-width: 1020px) {
    display: block;
  }
`;
const PMobile = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().h3)`
  padding-left: 10px;
  @media (min-width: 1020px) {
    display: none;
  }
`;
const DivBurguer = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().button)`
  height: 30px;
  width: 30px;
  border: none;
  background: transparent;
  padding: 0;
  margin-right: 10px;
  @media (min-width: 1020px) {
    display: none;
  }
`;
const Title = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().h3)`
  width: 100%;
`;
const DivImgAvatar = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  width: 50px;
  height: 50px;
  border-radius: 50%;
  overflow: hidden;
`;
const ImgAvatar = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().img)`
  width: 100%;
  height: 100%;
`;
const DivUsuarioAvatar = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  width: 20%;

  justify-content: space-around;
  position: relative;
  display: none;
  @media (min-width: 1020px) {
    display: flex;
  }
`;
const PUser = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().p)`
  text-align: center;
  display: none;
  @media (min-width: 1020px) {
    display: block;
  }
`;
const DivArrow = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  display: flex;
  align-items: center;
  justify-content: center;
  padding-left: 5px;
  padding-right: 5px;
  ${(props)=>props.state === "true" && "transform: rotate(180deg);"
}
`;
const ImgArrow = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().img)`
  width: 100%;
  height: auto;
`;
const DivUserArrow = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  cursor: pointer;
  display: none;
  @media (min-width: 1020px) {
    display: flex;
  }
`;
const DivOptions = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  ${(props)=>props.show === "false" && "display: none;"
}
  background: white;
  border-radius: 15px;
  position: absolute;
  width: 100%;
  height: fit-content;
  top: 100%;
  overflow: hidden;
  z-index: 20;
`;
const Poptions = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().p)`
  text-align: start;
  padding-left: 3%;
  margin: 0;
  height: 30px;
  display: flex;
  align-items: center;
  cursor: pointer;
  &:hover {
    background-color: #c0b7ef;
  }
`;


/***/ }),

/***/ 6372:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_createGlobalStyles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7609);
/* harmony import */ var _BodyColorChange__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4415);
/* harmony import */ var _pages_app__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2957);
/* harmony import */ var _LeftNav_LeftNav__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1386);
/* harmony import */ var _header_Header__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9797);
/* harmony import */ var _stylesinitwraper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2081);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _Reduxhooks__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5673);
/* harmony import */ var _Hooks_useAxiosGet__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3436);
/* harmony import */ var _ReduxSlices_CookiesSlice__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3844);
/* harmony import */ var _ReduxSlices_counterSlice__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4266);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_LeftNav_LeftNav__WEBPACK_IMPORTED_MODULE_6__, _header_Header__WEBPACK_IMPORTED_MODULE_7__, _pages_app__WEBPACK_IMPORTED_MODULE_5__, _BodyColorChange__WEBPACK_IMPORTED_MODULE_4__, _ReduxSlices_CookiesSlice__WEBPACK_IMPORTED_MODULE_12__]);
([_LeftNav_LeftNav__WEBPACK_IMPORTED_MODULE_6__, _header_Header__WEBPACK_IMPORTED_MODULE_7__, _pages_app__WEBPACK_IMPORTED_MODULE_5__, _BodyColorChange__WEBPACK_IMPORTED_MODULE_4__, _ReduxSlices_CookiesSlice__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);














const HeaderFooterWraper = ({ children  })=>{
    const MenuBur = (0,_Reduxhooks__WEBPACK_IMPORTED_MODULE_10__/* .useAppSelector */ .CG)(_ReduxSlices_counterSlice__WEBPACK_IMPORTED_MODULE_13__/* .MenuMobileBurguer */ .FA);
    const { 0: opa , 1: setOpa  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const dispatch = (0,_Reduxhooks__WEBPACK_IMPORTED_MODULE_10__/* .useAppDispatch */ .TL)();
    const { push  } = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    const token = (0,_Reduxhooks__WEBPACK_IMPORTED_MODULE_10__/* .useAppSelector */ .CG)(_ReduxSlices_CookiesSlice__WEBPACK_IMPORTED_MODULE_12__/* .Token */ .WU);
    const { Get  } = (0,_Hooks_useAxiosGet__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)("users/my-profile/", {
        completeInterceptor: {
            action: ()=>{
                setOpa(true);
            }
        },
        errorInterceptor: {
            action: ()=>{
                push("/login");
            }
        }
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (token.access !== "" && token.refresh !== "") {
            Get(token.access);
        } else push("/login");
    }, []);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_stylesinitwraper__WEBPACK_IMPORTED_MODULE_8__/* .DivInitWraperContainer */ .qH, {
        opa: opa.toString(),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styles_createGlobalStyles__WEBPACK_IMPORTED_MODULE_3__/* .GlobalStyle */ .ZL, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_BodyColorChange__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stylesinitwraper__WEBPACK_IMPORTED_MODULE_8__/* .DivBgBlackModal */ .V$, {
                show: MenuBur.toString(),
                onClick: ()=>dispatch((0,_ReduxSlices_counterSlice__WEBPACK_IMPORTED_MODULE_13__/* .HandleMenuMobile */ .sw)())
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stylesinitwraper__WEBPACK_IMPORTED_MODULE_8__/* .DivLateralMenu */ .dI, {
                show: MenuBur.toString(),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_LeftNav_LeftNav__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    area: "left",
                    show: true
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: "El Hector"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "icon",
                        href: _pages_app__WEBPACK_IMPORTED_MODULE_5__.prefix + __webpack_require__(4691)
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_header_Header__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                area: "nav"
            }),
            children,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_LeftNav_LeftNav__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                area: "left",
                show: false
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeaderFooterWraper);

});

/***/ }),

/***/ 2081:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "qH": () => (/* binding */ DivInitWraperContainer),
/* harmony export */   "V$": () => (/* binding */ DivBgBlackModal),
/* harmony export */   "dI": () => (/* binding */ DivLateralMenu)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const DivInitWraperContainer = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  opacity: ${(props)=>props.opa === "true" ? "1" : "0"
};
  position: relative;
  width: 100%;
  height: 100vh;
  display: grid;
  grid-template-rows: 10% 90%;
  grid-template-areas:
    "nav"
    ".";

  @media (min-width: 1020px) {
    grid-template-columns: 15% 85%;
    grid-template-rows: 10% 90%;
    grid-template-areas:
      "left nav"
      "left .";
  }
`;
const DivBgBlackModal = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  display: ${(props)=>props.show === "false" && "none"
};
  position: absolute;
  left: 0;
  top: 0;
  margin: auto;
  z-index: 50;
  width: 100vw;
  height: 100vh;
  background: black;
  opacity: 0.5;
  @media (min-width: 1020px) {
    display: none;
  }
`;
const DivLateralMenu = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
  display: ${(props)=>props.show === "false" && "none"
};
  background: white;
  width: 300px;
  height: 100%;
  position: absolute;
  left: 0;
  top: 0;
  margin: auto;
  z-index: 60;
  @media (min-width: 1020px) {
    display: none;
  }
`;


/***/ }),

/***/ 7609:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Qs": () => (/* binding */ BackPrimary),
/* harmony export */   "HW": () => (/* binding */ BackSecondary),
/* harmony export */   "ZL": () => (/* binding */ GlobalStyle)
/* harmony export */ });
/* unused harmony exports ColorPrimary, ColorSecondary, BackTerciary, HandyColor, GradienteHandy */
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const ColorPrimary = "black";
const ColorSecondary = "white";
const BackPrimary = "#f3f4f6";
const BackSecondary = "#18191a";
const BackTerciary = "#202c36";
const HandyColor = "#D68502";
const GradienteHandy = (deg = 180)=>`linear-gradient(${deg}deg,  #D94C32, #F8AA39)`
;
const GlobalStyle = styled_components__WEBPACK_IMPORTED_MODULE_0__.createGlobalStyle`

//Estilos por defecto que trae React
body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

code {
  font-family: source-code-pro, Menlo, Monaco, Consolas, 'Courier New',
    monospace;
}


//Estilos para Grid Area

/*Grid Area First Mobile*/

/*min 640px*/
.contenedor {
grid-template-areas: "header header header"
                    "contenido contenido contenido"
                    "sidebar sidebar sidebar"
                    "widget-1 widget-1 widget-1"
                    "widget-2 widget-2 widget-2"
                    "footer footer footer"
;
}


/*min 768px*/
@media screen and (min-width: 768px){
.contenedor{
grid-template-areas:    "header header header"
                        "contenido contenido contenido"
                        "sidebar sidebar sidebar"
                        "widget-1 widget-1 widget-2"
                        "footer footer footer"
;
}    
}

/*min 1024px*/
@media screen and (min-width: 1024px){
.contenedor{
grid-template-areas:    "header header header"
                        "contenido contenido sidebar"
                        "widget-1 widget-2 sidebar"
                        "footer footer footer"
;
}

}

/*min 1280px*/
@media screen and (min-width: 1280px){
.contenedor{
grid-template-areas:    "header header header"
                        "contenido contenido sidebar"
                        "widget-1 widget-1 sidebar"
                        "widget-2 widget-2 sidebar"
                        "footer footer footer"
;
}

}

/*min 1536px*/

`;


/***/ }),

/***/ 257:
/***/ ((module) => {

module.exports = "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIj8+PHN2ZyBmaWxsPSIjMDAwMDAwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciICB2aWV3Qm94PSIwIDAgMzAgMzAiIHdpZHRoPSIzMHB4IiBoZWlnaHQ9IjMwcHgiPiAgICA8cGF0aCBkPSJNMjQuNzA3LDguNzkzbC02LjUtNi41QzE4LjAxOSwyLjEwNSwxNy43NjUsMiwxNy41LDJIN0M1Ljg5NSwyLDUsMi44OTUsNSw0djIyYzAsMS4xMDUsMC44OTUsMiwyLDJoMTZjMS4xMDUsMCwyLTAuODk1LDItMiBWOS41QzI1LDkuMjM1LDI0Ljg5NSw4Ljk4MSwyNC43MDcsOC43OTN6IE0xOCwxMGMtMC41NTIsMC0xLTAuNDQ4LTEtMVYzLjkwNEwyMy4wOTYsMTBIMTh6Ii8+PC9zdmc+"

/***/ }),

/***/ 5672:
/***/ ((module) => {

module.exports = "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIj8+PHN2ZyBmaWxsPSIjMDAwMDAwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciICB2aWV3Qm94PSIwIDAgMjQgMjQiIHdpZHRoPSIyNHB4IiBoZWlnaHQ9IjI0cHgiPiAgICA8cGF0aCBkPSJNMTksM0g1QzMuODk3LDMsMywzLjg5NywzLDV2MTRjMCwxLjEwMywwLjg5NywyLDIsMmgxNGMxLjEwMywwLDItMC44OTcsMi0yVjVDMjEsMy44OTcsMjAuMTAzLDMsMTksM3ogTTE1LDE5aC0ydi0zbDEtMSBsMSwxVjE5eiBNMTUsOEg5VjZoNlY4eiBNMTksMTloLTJ2LTNsMS0xbDEsMVYxOXoiLz48L3N2Zz4="

/***/ }),

/***/ 5238:
/***/ ((module) => {

module.exports = "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIj8+PHN2ZyBmaWxsPSIjMDAwMDAwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciICB2aWV3Qm94PSIwIDAgMjQgMjQiIHdpZHRoPSIyNHB4IiBoZWlnaHQ9IjI0cHgiPiAgICA8cGF0aCBkPSJNMjAsNmgtOGwtMi0ySDRDMi45LDQsMiw0LjksMiw2djEyYzAsMS4xLDAuOSwyLDIsMmgxNmMxLjEsMCwyLTAuOSwyLTJWOEMyMiw2LjksMjEuMSw2LDIwLDZ6Ii8+PC9zdmc+"

/***/ }),

/***/ 6103:
/***/ ((module) => {

module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTQiIGhlaWdodD0iOCIgdmlld0JveD0iMCAwIDE0IDgiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxwYXRoIGQ9Ik0xMyAxTDcgN0wxIDEiIHN0cm9rZT0iIzIxMjEyMSIgc3Ryb2tlLXdpZHRoPSIyIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiLz4KPC9zdmc+Cg=="

/***/ }),

/***/ 1186:
/***/ ((module) => {

module.exports = "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pg0KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDE4LjEuMSwgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPg0KPHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJDYXBhXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4Ig0KCSB2aWV3Qm94PSIwIDAgMzQuMDc1IDM0LjA3NSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzQuMDc1IDM0LjA3NTsiIHhtbDpzcGFjZT0icHJlc2VydmUiPg0KPGc+DQoJPGc+DQoJCTxwYXRoIHN0eWxlPSJmaWxsOiMwMTAwMDI7IiBkPSJNMjQuNTcsMzQuMDc1Yy0wLjUwNSwwLTEuMDExLTAuMTkxLTEuMzk2LTAuNTc3TDguMTEsMTguNDMyYy0wLjc3MS0wLjc3MS0wLjc3MS0yLjAxOSwwLTIuNzkNCgkJCUwyMy4xNzQsMC41NzhjMC43NzEtMC43NzEsMi4wMi0wLjc3MSwyLjc5MSwwczAuNzcxLDIuMDIsMCwyLjc5bC0xMy42NywxMy42NjlsMTMuNjcsMTMuNjY5YzAuNzcxLDAuNzcxLDAuNzcxLDIuMDIxLDAsMi43OTINCgkJCUMyNS41OCwzMy44ODMsMjUuMDc1LDM0LjA3NSwyNC41NywzNC4wNzV6Ii8+DQoJPC9nPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPC9zdmc+DQo="

/***/ }),

/***/ 6872:
/***/ ((module) => {

module.exports = "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIj8+PHN2ZyBmaWxsPSIjMDAwMDAwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciICB2aWV3Qm94PSIwIDAgMzAgMzAiIHdpZHRoPSIzMHB4IiBoZWlnaHQ9IjMwcHgiPiAgICA8cGF0aCBkPSJNIDQgNSBDIDIuODk1IDUgMiA1Ljg5NSAyIDcgTCAyIDIzIEMgMiAyNC4xMDUgMi44OTUgMjUgNCAyNSBMIDEyIDI1IEMgMTMuMTA1IDI1IDE0IDI1Ljg5NSAxNCAyNyBMIDE0IDcgQyAxNCA1Ljg5NSAxMy4xMDUgNSAxMiA1IEwgNCA1IHogTSAxOCA1IEMgMTYuODk1IDUgMTYgNS44OTUgMTYgNyBMIDE2IDI3IEMgMTYgMjUuODk1IDE2Ljg5NSAyNSAxOCAyNSBMIDI2IDI1IEMgMjcuMTA1IDI1IDI4IDI0LjEwNSAyOCAyMyBMIDI4IDcgQyAyOCA1Ljg5NSAyNy4xMDUgNSAyNiA1IEwgMTggNSB6Ii8+PC9zdmc+"

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = "data:image/svg+xml;base64,PHN2ZyBmaWxsPSIjMDAwMDAwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciICB2aWV3Qm94PSIwIDAgMzAgMzAiIHdpZHRoPSIzMHB4IiBoZWlnaHQ9IjMwcHgiPjxwYXRoIGQ9Ik0gMyA3IEEgMS4wMDAxIDEuMDAwMSAwIDEgMCAzIDkgTCAyNyA5IEEgMS4wMDAxIDEuMDAwMSAwIDEgMCAyNyA3IEwgMyA3IHogTSAzIDE0IEEgMS4wMDAxIDEuMDAwMSAwIDEgMCAzIDE2IEwgMjcgMTYgQSAxLjAwMDEgMS4wMDAxIDAgMSAwIDI3IDE0IEwgMyAxNCB6IE0gMyAyMSBBIDEuMDAwMSAxLjAwMDEgMCAxIDAgMyAyMyBMIDI3IDIzIEEgMS4wMDAxIDEuMDAwMSAwIDEgMCAyNyAyMSBMIDMgMjEgeiIvPjwvc3ZnPg=="

/***/ }),

/***/ 1147:
/***/ ((module) => {

module.exports = "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIj8+PHN2ZyBmaWxsPSIjMDAwMDAwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciICB2aWV3Qm94PSIwIDAgMjQgMjQiIHdpZHRoPSIyNHB4IiBoZWlnaHQ9IjI0cHgiPiAgICA8cGF0aCBkPSJNMTksM0g1QzMuODk3LDMsMywzLjg5NywzLDV2MTRjMCwxLjEwMywwLjg5NywyLDIsMmgxNGMxLjEwMywwLDItMC44OTcsMi0yVjVDMjEsMy44OTcsMjAuMTAzLDMsMTksM3ogTTYuMjc3LDcuNTc4IGMwLjI3OC0wLjM2NywwLjY5OS0wLjU5NiwxLjE1OC0wLjU3N0M4LjEyMSw3LjAyOSw4LjUsNy41MjIsOC41LDcuNTIyczAuMzc5LTAuNDkzLDEuMDY0LTAuNTIxYzAuNDYtMC4wMTksMC44ODEsMC4yMSwxLjE1OCwwLjU3NyBjMC45NjYsMS4yNzYtMC44NjMsMi43NjktMS4yOTMsMy4xN2MtMC4yNTcsMC4yNC0wLjU3NSwwLjUyNS0wLjc2NCwwLjY5M2MtMC4wOTUsMC4wODUtMC4yMzYsMC4wODUtMC4zMzEsMCBjLTAuMTktMC4xNjktMC41MDctMC40NTQtMC43NjQtMC42OTNDNy4xNCwxMC4zNDcsNS4zMTEsOC44NTQsNi4yNzcsNy41Nzh6IE0xOCwxN0g2di0yaDEyVjE3eiBNMTgsMTNoLTZ2LTJoNlYxM3ogTTE4LDloLTRWN2g0Vjl6Ii8+PC9zdmc+"

/***/ }),

/***/ 6670:
/***/ ((module) => {

module.exports = "data:image/svg+xml;base64,PHN2ZyBmaWxsPSIjMDAwMDAwIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciICB2aWV3Qm94PSIwIDAgMjQgMjQiIHdpZHRoPSIyNHB4IiBoZWlnaHQ9IjI0cHgiPjxwYXRoIGQ9Ik0gOCAyIEMgNi4zNTUwMzAyIDIgNSAzLjM1NTAzMDIgNSA1IEwgNSAxNiBMIDIgMTYgTCAyIDE5IEMgMiAyMC42NDQ5NyAzLjM1NTAzMDIgMjIgNSAyMiBMIDE0IDIyIEwgMTUgMjIgQyAxNi42NDQ5NyAyMiAxOCAyMC42NDQ5NyAxOCAxOSBMIDE4IDggTCAyMiA4IEwgMjIgNSBDIDIyIDMuMzU1MDMwMiAyMC42NDQ5NyAyIDE5IDIgTCA4IDIgeiBNIDE5IDQgQyAxOS41NjUwMyA0IDIwIDQuNDM0OTY5OCAyMCA1IEwgMjAgNiBMIDE4IDYgTCAxOCA1IEMgMTggNC40MzQ5Njk4IDE4LjQzNDk3IDQgMTkgNCB6IE0gNCAxOCBMIDExLjk5MDIzNCAxOCBMIDEyIDE5LjAyNTM5MSBMIDEyIDE5LjAyNzM0NCBDIDEyLjAwNDY1NCAxOS4zNjk4ODkgMTIuMDgxMjI3IDE5LjY5MzY5NiAxMi4xOTMzNTkgMjAgTCA1IDIwIEMgNC40MzQ5Njk4IDIwIDQgMTkuNTY1MDMgNCAxOSBMIDQgMTggeiIvPjwvc3ZnPg=="

/***/ }),

/***/ 368:
/***/ ((module) => {

module.exports = "/_next/static/images/grass-71de26fe3d0bd693956da68091d304be.jpeg";

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = "/_next/static/images/logo-84b330ed17e4ae0851764a33f678349d.png";

/***/ }),

/***/ 4691:
/***/ ((module) => {

module.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMDAgMTAwIj48ZyBmaWxsPSIjNzY0QUJDIj48cGF0aCBkPSJNNjUuNiA2NS40YzIuOS0uMyA1LjEtMi44IDUtNS44LS4xLTMtMi42LTUuNC01LjYtNS40aC0uMmMtMy4xLjEtNS41IDIuNy01LjQgNS44LjEgMS41LjcgMi44IDEuNiAzLjctMy40IDYuNy04LjYgMTEuNi0xNi40IDE1LjctNS4zIDIuOC0xMC44IDMuOC0xNi4zIDMuMS00LjUtLjYtOC0yLjYtMTAuMi01LjktMy4yLTQuOS0zLjUtMTAuMi0uOC0xNS41IDEuOS0zLjggNC45LTYuNiA2LjgtOC0uNC0xLjMtMS0zLjUtMS4zLTUuMS0xNC41IDEwLjUtMTMgMjQuNy04LjYgMzEuNCAzLjMgNSAxMCA4LjEgMTcuNCA4LjEgMiAwIDQtLjIgNi0uNyAxMi44LTIuNSAyMi41LTEwLjEgMjgtMjEuNHoiLz48cGF0aCBkPSJNODMuMiA1M2MtNy42LTguOS0xOC44LTEzLjgtMzEuNi0xMy44SDUwYy0uOS0xLjgtMi44LTMtNC45LTNoLS4yYy0zLjEuMS01LjUgMi43LTUuNCA1LjguMSAzIDIuNiA1LjQgNS42IDUuNGguMmMyLjItLjEgNC4xLTEuNSA0LjktMy40SDUyYzcuNiAwIDE0LjggMi4yIDIxLjMgNi41IDUgMy4zIDguNiA3LjYgMTAuNiAxMi44IDEuNyA0LjIgMS42IDguMy0uMiAxMS44LTIuOCA1LjMtNy41IDguMi0xMy43IDguMi00IDAtNy44LTEuMi05LjgtMi4xLTEuMSAxLTMuMSAyLjYtNC41IDMuNiA0LjMgMiA4LjcgMy4xIDEyLjkgMy4xIDkuNiAwIDE2LjctNS4zIDE5LjQtMTAuNiAyLjktNS44IDIuNy0xNS44LTQuOC0yNC4zeiIvPjxwYXRoIGQ9Ik0zMi40IDY3LjFjLjEgMyAyLjYgNS40IDUuNiA1LjRoLjJjMy4xLS4xIDUuNS0yLjcgNS40LTUuOC0uMS0zLTIuNi01LjQtNS42LTUuNGgtLjJjLS4yIDAtLjUgMC0uNy4xLTQuMS02LjgtNS44LTE0LjItNS4yLTIyLjIuNC02IDIuNC0xMS4yIDUuOS0xNS41IDIuOS0zLjcgOC41LTUuNSAxMi4zLTUuNiAxMC42LS4yIDE1LjEgMTMgMTUuNCAxOC4zIDEuMy4zIDMuNSAxIDUgMS41LTEuMi0xNi4yLTExLjItMjQuNi0yMC44LTI0LjYtOSAwLTE3LjMgNi41LTIwLjYgMTYuMS00LjYgMTIuOC0xLjYgMjUuMSA0IDM0LjgtLjUuNy0uOCAxLjgtLjcgMi45eiIvPjwvZz48L3N2Zz4K"

/***/ })

};
;