"use strict";
(() => {
var exports = {};
exports.id = 170;
exports.ids = [170];
exports.modules = {

/***/ 9719:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const countHandler = async (request, response)=>{
    const { amount =1  } = request.body;
    // simulate IO latency
    await new Promise((resolve)=>setTimeout(resolve, 500)
    );
    response.json({
        data: amount
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (countHandler);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(9719));
module.exports = __webpack_exports__;

})();